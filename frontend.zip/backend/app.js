import express from "express";
import { Server } from "socket.io";
import { createServer } from "http";
const app = express();
const port = 3000;
const server = createServer(app);
let users = {};
let socketids = [];
const roomuser =[];
const socketiduser = new Map();
const io = new Server(server, {
  cors: {
    origin: "*"
  },
});

app.get("/", (req, res) => {
  res.send("HEllo world");
});
const roomtohost ={};
const socketidtoRoomMap = new Map();
const socketidToUserMap = new Map();


io.on("connection", (socket) => {
  socket.on("username", (m) => {
    if (!nameTaken(m.userName)) {
      users[socket.id] = m;
      socketids.push(socket.id);
      socket.emit("approved username");
    } else {
      socket.emit("duplicate username", m);
    }
  });

  socket.on("join-room", (roomId, userId) => {
    console.log(`a new user ${userId} joined room ${roomId}`);
    socket.join(roomId);
    socketidToUserMap.set(socket.id, userId);
    socketidtoRoomMap.set(socket.id, roomId);
    roomuser.push({room:roomId,userid:userId,sId: socket.id});
    if (!roomtohost[roomId]) {
      roomtohost[roomId]=socket.id;
    }
    console.log("room host", roomtohost);
    io.in(roomId).emit("user-connected", userId,roomtohost,roomuser);
    io.in(roomId).emit("host-user",roomtohost[roomId],roomuser);


  });

  socket.on("user-toggle-audio", (userId, roomId) => {
    socket.join(roomId);
    socket.broadcast.to(roomId).emit("user-toggle-audio", userId);
  });

  socket.on("user-toggle-video", (userId, roomId) => {
    socket.join(roomId);
    socket.broadcast.to(roomId).emit("user-toggle-video", userId);
  });

  socket.on("user-leave", (userId, roomId) => {
    socket.join(roomId);
    console.log("user leave", socket.id);
    socket.broadcast.to(roomId).emit("user-leave", userId);
  });
  socket.on("disconnect", () => {
    console.log("disssssss", socket.id);
    const curr_room = socketidtoRoomMap.get(socket.id);
    const userId = socketidToUserMap.get(socket.id);
    socket.broadcast.to(curr_room).emit("user-leave", userId);
  });
});

function nameTaken(userName) {
  for (const socketid in users) {
    console.log(
      "usssseerrss",
      socketid,
      users[socketid],
      users[socketid].userName
    );
    if (users[socketid].userName === userName) {
      return true;
    }
  }

  return false;
}

server.listen(port, () => {
  console.log(`server is running on ${port}`);
});
