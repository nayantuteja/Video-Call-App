"use client";
import React from "react";
import Chatroom from "./Chatroom";

function page() {
  return (
    <div className="flex  flex-col flex-wrap items-center justify-center">
      <Chatroom />
    </div>
  );
}

export default page;
